﻿using GreenWichData.Data;
using GreenWichData.ServiceImpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GreenWichWeb.Controllers
{
    public class TrainerController : Controller
    {
        private GreenWichDBEntities dataContext = new GreenWichDBEntities();
        TrainerServiceImpl service = new TrainerServiceImpl();
        // GET: Trainer
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult IndexSeeSession(string SearchString)
        {


            var ss = from s in dataContext.Sessions select s;
            if (!string.IsNullOrEmpty(SearchString))
            {
                ss = ss.Where(s => s.Name.Contains(SearchString) || s.Event_Content.Contains(SearchString) || s.Rating.Contains(SearchString));
            }
            return View(ss);
        }

        public ActionResult IndexSeeBooking()
        {

            return View(dataContext.Bookings.ToList());
        }

         [HttpGet]
        public ActionResult BookingEdit(int ? id)
        {
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name");
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name");
           
            return View();
        }

         [HttpPost]
         public ActionResult BookingEdit(Booking booking)
         {
             service.EditBooking(booking);
             ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", booking.Staff_ID);
             ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", booking.Event_ID);
             ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name", booking.Session_ID);

             return RedirectToAction("IndexSeeBooking");
         }
    }
}