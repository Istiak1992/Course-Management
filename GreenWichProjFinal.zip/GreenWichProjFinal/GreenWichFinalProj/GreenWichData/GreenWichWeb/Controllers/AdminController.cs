﻿using GreenWichData.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GreenWichData.ServiceImpl;
using System.Net;
using System.Data.Entity;


namespace GreenWichWeb.Controllers
{
    public class AdminController : Controller
    {
         AdminServiceImpl service = new AdminServiceImpl();
         GreenWichDBEntities dataContext = new GreenWichDBEntities();
         public ActionResult Index()
         {
             return View();
         }
         /* CRUD Operation  for Event*/
         public ActionResult IndexEvent(string SearchString)
         {
             var ev = from s in dataContext.Events select s;
             if (!string.IsNullOrEmpty(SearchString))
             {
                 ev = ev.Where(s => s.Name.Contains(SearchString) || s.Event_Code.Contains(SearchString));
             }
             return View(ev);
            // return View(dataContext.Events.ToList());
         }

        [HttpGet]
        public ActionResult CreateEvent()
        {
            //ViewData["StaffIDList"]=new SelectList(dataContext.Staffs,"ID","Name");
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name");

            
            return View();
        }

        [HttpPost]
        public ActionResult CreateEvent(Event event1)
        {
            if (ModelState.IsValid)
            {
                service.AddEvent(event1);
                return RedirectToAction("IndexEvent");
            }
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", event1.Staff_ID);
           
            return View(event1);
        }


        [HttpGet]
        public ActionResult EventDetailsGet(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = dataContext.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);

        }


       [HttpGet]
        public ActionResult EventEditGet(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = dataContext.Events.Find(id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name");
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name");
            ViewBag.Trainer_ID = new SelectList(dataContext.Trainers, "ID", "Name");
            
            return View(@event);
        }

       [HttpPost]
       [ValidateAntiForgeryToken]
       public ActionResult EventEditGet(Event event1)
       {
           service.AddEvent(event1);
           //if (ModelState.IsValid)
           //{
           //    dataContext.Entry(@event).State = EntityState.Modified;
           //    dataContext.SaveChanges();
           //    return RedirectToAction("IndexEvent");
           //}
           ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name", event1.Session_ID);
           ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", event1.Staff_ID);
           ViewBag.Trainer_ID = new SelectList(dataContext.Trainers, "ID", "Name", event1.Trainer_ID);
           //return View(@event);
           return View(event1);
       }

       // GET: Events/Delete/5
        [HttpGet]
       public ActionResult EventDelete(int? id)
       {
           if (id == null)
           {
               return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
           }
           Event @event = dataContext.Events.Find(id);
           if (@event == null)
           {
               return HttpNotFound();
           }
           return View(@event);
       }

       // POST: Events/Delete/5
       [HttpPost]
      
       public ActionResult EventDelete(int id)
       {
           service.DeleteEvent(id);
           
           return RedirectToAction("IndexEvent");
       }

    

        /*For Session*/

       public ActionResult IndexSession(string SearchString)
       {
           var ss = from s in dataContext.Sessions select s;
           if (!string.IsNullOrEmpty(SearchString))
           {
               ss = ss.Where(s => s.Name.Contains(SearchString) || s.Event_Content.Contains(SearchString) || s.Rating.Contains(SearchString));
           }
           return View(ss);
           //return View(dataContext.Sessions.ToList());
       }

        [HttpGet]
        public ActionResult CreateSession()
        {
            ViewBag.Trainer_ID = new SelectList(dataContext.Trainers, "ID", "Name");
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");

            return View();
        }

        [HttpPost]
        public ActionResult CreateSession(Session session)
        {
            service.InsertSession(session);
            ViewBag.Trainer_ID = new SelectList(dataContext.Trainers, "ID", "Name", session.Trainer_ID);
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", session.Event_ID);
            return View(session);
        }

        public ActionResult SessionDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Session session = dataContext.Sessions.Find(id);
            if (session == null)
            {
                return HttpNotFound();
            }
            return View(session);
        }


         [HttpGet]
        public ActionResult SessionEdit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Session session = dataContext.Sessions.Find(id);
            if (session == null)
            {
                return HttpNotFound();
            }
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
            ViewBag.Trainer_ID = new SelectList(dataContext.Trainers, "ID", "Name");

            return View(session);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
         public ActionResult SessionEdit(Session session)
        {
            service.InsertSession(session);

            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", session.Event_ID);
            ViewBag.Trainer_ID = new SelectList(dataContext.Trainers, "ID", "Name",session.Trainer_ID);
            return View(session);
        }
        
   // GET: Events/Delete/5
   [HttpGet]
   public ActionResult SessionDelete(int? id)
   {
       if (id == null)
       {
           return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
       }
       Session session = dataContext.Sessions.Find(id);
       if (session == null)
       {
           return HttpNotFound();
       }
       return View(session);
   }

   // POST: Events/Delete/5
   [HttpPost]

   public ActionResult SessionDelete(int id)
   {
       service.DeleteSession(id);

       return RedirectToAction("IndexSession");
   }

    


        /*For Staff*/

   public ActionResult IndexStaff(string SearchString)
        {
            var staff = from s in dataContext.Staffs select s;
            if (!string.IsNullOrEmpty(SearchString))
            {
                staff = staff.Where(s => s.Name.Contains(SearchString) || s.Organization.Contains(SearchString) || s.Designation.Contains(SearchString));
            }
            return View(staff);
            //return View(dataContext.Staffs.ToList());
        }

        [HttpGet]
        public ActionResult CreateStaff()
        {
            
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");

            return View();
        }

        [HttpPost]
        public ActionResult CreateStaff(Staff staff)
        {
            service.InserStaff(staff);
          
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", staff.Event_ID);
            return View(staff);
        }

        public ActionResult StaffDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff staff = dataContext.Staffs.Find(id);
            if (staff == null)
            {
                return HttpNotFound();
            }
            return View(staff);
        }


        [HttpGet]
        public ActionResult StaffEdit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff staff = dataContext.Staffs.Find(id);
            if (staff == null)
            {
                return HttpNotFound();
            }
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
           

            return View(staff);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult StaffEdit(Staff staff)
        {
            service.EditStaff(staff);

            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", staff.Event_ID);
            
            return RedirectToAction("IndexStaff");
        }

        // GET: Events/Delete/5
        [HttpGet]
        public ActionResult StaffDelete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Staff staff = dataContext.Staffs.Find(id);
            if (staff == null)
            {
                return HttpNotFound();
            }
            return View(staff);
        }

        // POST: Events/Delete/5
        [HttpPost]

        public ActionResult StaffDelete(int id)
        {
            service.DeleteStaff(id);

            return RedirectToAction("IndexStaff");
        }


        /*For Assign Staff*/
        public ActionResult IndexAssignedStaff()
        {
            return View(dataContext.AssignedStaffs.ToList());
        }

        [HttpGet]
        public ActionResult CreateAssignedStaff()
        {
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name");
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name");


            return View();
        }

        [HttpPost]
        public ActionResult CreateAssignedStaff(AssignedStaff assigned)
        {
            service.AddAssignedStaff(assigned);

            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", assigned.Staff_ID);
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name",assigned.Event_ID);
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name", assigned.Session_ID);
            return View(assigned);
        }

        [HttpGet]
        public ActionResult EventAssign()
        {
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name");
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name");


            return View();
        }

        [HttpPost]
        public ActionResult EventAssign(AssignedStaff assigned)
        {
            Staff staff = dataContext.Staffs.Where(e => e.ID == assigned.Staff_ID).FirstOrDefault();
            Event event1 = dataContext.Events.Where(e => e.ID == assigned.Event_ID).FirstOrDefault();

            service.AssaignStaffToEvent(staff, event1);

            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", assigned.Staff_ID);
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", assigned.Event_ID);
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name", assigned.Session_ID);
            return View(assigned);
        }





    }
}
