﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GreenWichData.ServiceInterface;
using GreenWichData.ServiceImpl;
using GreenWichData.Data;

namespace GreenWichWeb.Controllers
{
    public class StaffController : Controller
    {
       StaffServiceImpl service =new StaffServiceImpl();
        GreenWichDBEntities dataContext = new GreenWichDBEntities();

        public ActionResult Index()
        {
            return View();
        }
        // GET: Staff
        [HttpGet]
        public ActionResult CreateBookSession()
        {
            ViewBag.Staff_ID =new SelectList(dataContext.Staffs,"ID", "Name");
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name");
            return View();
        }

        [HttpPost]
        public ActionResult CreateBookSession(Booking booking)
        {
            service.BookSession(booking);
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", booking);
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", booking);
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name", booking);
            return RedirectToAction("Index");
        }

        public ActionResult CreateBookColleagues()
        {
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name");
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name");
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name");
            return View();
        }

        [HttpPost]
        public ActionResult CreateBookColleagues(Booking booking)
        {
            service.BookColleagues(booking);
            ViewBag.Staff_ID = new SelectList(dataContext.Staffs, "ID", "Name", booking);
            ViewBag.Event_ID = new SelectList(dataContext.Events, "ID", "Name", booking);
            ViewBag.Session_ID = new SelectList(dataContext.Sessions, "ID", "Name", booking);
            return RedirectToAction("Index");
        }

        
    }
}