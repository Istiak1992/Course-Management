﻿using GreenWichData.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GreenWichWeb.Controllers
{
    public class ManagerController : Controller
    {
        GreenWichDBEntities db = new GreenWichDBEntities();
        // GET: Manager
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult StaffReport(string SearchString)
        {
            var staff = from s in db.Staffs select s;
            if (!string.IsNullOrEmpty(SearchString))
            {
                staff = staff.Where(s => s.Name.Contains(SearchString) || s.Organization.Contains(SearchString) || s.Designation.Contains(SearchString) );
            }
            return View(staff);
        }
        public ActionResult BookingReport()
        {
            return View(db.Bookings.ToList());
        }
        public ActionResult TrainerReport(string SearchString)
        {
            var t = from s in db.Trainers select s;
            if (!string.IsNullOrEmpty(SearchString))
            {
                t = t.Where(s => s.Name.Contains(SearchString));
            }
            return View(t);
        }
        public ActionResult SessionReport(string SearchString)
        {
            var ss = from s in db.Sessions select s;
            if (!string.IsNullOrEmpty(SearchString))
            {
                ss = ss.Where(s => s.Name.Contains(SearchString) || s.Event_Content.Contains(SearchString) || s.Rating.Contains(SearchString));
            }
            return View(ss);
        }

        public ActionResult TrainingReport()
        {
            return View(db.Trainings.ToList());
        }
        
        
    }
}