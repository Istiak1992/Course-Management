﻿using GreenWichData.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GreenWichWeb.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Login log)
        {
            using (GreenWichDBEntities db = new GreenWichDBEntities())
            {
                var user = db.Logins.Single(u => u.UserName == log.UserName && u.Password == log.Password && u.Role==log.Role);
                if (user != null)
                {
                    Session["UserID"] = log.ID.ToString();
                    Session["UserName"] = log.UserName.ToString();
                    Session["Role"] = log.Role.ToString();

                    if (Session["Role"].ToString() == "Admin")
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    else if (Session["Role"].ToString() == "Staff")
                    {
                        return RedirectToAction("Index", "Staff");
                    }
                    else if (Session["Role"].ToString() == "Manager")
                    {
                        return RedirectToAction("Index", "Manager");
                    }
                    else if (Session["Role"].ToString() == "Trainer")
                    {
                        return RedirectToAction("Index", "Trainer");
                    }
                   
                }
                else
                {
                    ModelState.AddModelError("", "Please Enter a Valid User Name Or Password");
                }
            }
            return View();

        }
        public ActionResult logged()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("login");
            }
        }
    }
}
