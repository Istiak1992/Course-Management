﻿using GreenWichData.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreenWichData.ServiceInterface
{
    interface StaffService
    {
        void BookSession(Booking booking);
        void BookColleagues(Booking booking);
        void CancelBookings(int StaffID);
        List<Session> SeeSessions(int StaffID);

    }
}
