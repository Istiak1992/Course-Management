﻿using GreenWichData.Data;
using GreenWichData.ServiceInterface;
using System;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreenWichData.ServiceImpl
{
  public  class TrainerServiceImpl:TrainerService
    {
     
        private GreenWichDBEntities dataContext = new GreenWichDBEntities();

        public void EditBooking(Booking bookingTrainer)
        {
            dataContext.Entry(bookingTrainer).State = EntityState.Modified;
            dataContext.SaveChanges();
        }
    }
}
