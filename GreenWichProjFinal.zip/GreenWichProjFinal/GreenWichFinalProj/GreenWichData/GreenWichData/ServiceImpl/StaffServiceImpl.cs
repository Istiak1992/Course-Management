﻿using GreenWichData.Data;
using GreenWichData.ServiceInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreenWichData.ServiceImpl
{
  public class StaffServiceImpl:StaffService
    {
        private GreenWichDBEntities dataContext = new GreenWichDBEntities();

        public void BookSession(Booking booking)
        {
            var stID = booking.Staff_ID;
            var seID = booking.Session_ID;
            int StaffID = Convert.ToInt32(stID);
            int SessionID = Convert.ToInt32(seID);
           var IsAvailabe = dataContext.Sessions
                        .Where(e => e.ID == SessionID && e.Booking< e.Capacity).FirstOrDefault();
           if (IsAvailabe != null)
           {
               IsAvailabe.Booking++;
            //   Booking booking = new Booking();
               booking.Event_ID = IsAvailabe.Event_ID;
               booking.Session_ID = IsAvailabe.ID;
               booking.Staff_ID = StaffID;
               dataContext.Bookings.Add(booking);
           }
           else
           {
               WaitingList waiting = new WaitingList();
               waiting.Event_ID = IsAvailabe.Event_ID;
               waiting.Session_ID = IsAvailabe.ID;
               waiting.Staff_ID = StaffID;
               dataContext.WaitingLists.Add(waiting);
           }
           dataContext.SaveChanges();
        }

        public void BookColleagues(Booking booking)
        {
            var stID = booking.Staff_ID;
            var seID = booking.Session_ID;
            int ColleagueID = Convert.ToInt32(stID);
            int SessionID = Convert.ToInt32(seID);
            var IsAvailabe = dataContext.Sessions
                         .Where(e => e.ID == SessionID && e.Booking < e.Capacity).FirstOrDefault();
            if (IsAvailabe != null)
            {
                IsAvailabe.Booking++;
               // Booking booking = new Booking();
                booking.Event_ID = IsAvailabe.Event_ID;
                booking.Session_ID = IsAvailabe.ID;
                booking.Staff_ID = ColleagueID;
                dataContext.Bookings.Add(booking);
            }
            else
            {
                WaitingList waiting = new WaitingList();
                waiting.Event_ID = IsAvailabe.Event_ID;
                waiting.Session_ID = IsAvailabe.ID;
                waiting.Staff_ID = ColleagueID;
                dataContext.WaitingLists.Add(waiting);
            }
            dataContext.SaveChanges();
        }

        public void CancelBookings(int StaffID)
        {
           Booking booking = dataContext.Bookings.Where(e => e.Staff_ID == StaffID).FirstOrDefault();
           dataContext.Bookings.Remove(booking);
           dataContext.SaveChanges();
        }

        public List<Session> SeeSessions(int StaffID)
        {
            Training training = dataContext.Trainings.Where(e=>e.Staff_ID == StaffID).FirstOrDefault();
            if (training != null)
         
	{
		      return dataContext.Sessions.Where(e=>e.ID == training.Session_ID).ToList();
	}
            return null;
        }
    }
}
