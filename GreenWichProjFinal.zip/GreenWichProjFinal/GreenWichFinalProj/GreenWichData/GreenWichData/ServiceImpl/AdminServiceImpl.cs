﻿using GreenWichData.ServiceInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GreenWichData.Data;
using System.Data.Entity;


namespace GreenWichData.ServiceImpl
{
    public class AdminServiceImpl : AdminService
    {
        private GreenWichDBEntities dataContext = new GreenWichDBEntities();

        public void AddEvent(Event eventParam)
        {
            dataContext.Events.Add(eventParam);
            dataContext.SaveChanges();
        }

        public void DeleteEvent(int id) {
            Event event1 = dataContext.Events.Find(id);
            dataContext.Events.Remove(event1);
            dataContext.SaveChanges();
        }

        public void AssaignStaffToEvent(Staff staffParam, Event eventParam)
        {
            Staff staff = dataContext.Staffs.Where(e => e.ID == staffParam.ID).FirstOrDefault();
            if (staff != null)
            {
                Event evnt = dataContext.Events.Where(e => e.ID == eventParam.ID).FirstOrDefault();
                Session session = dataContext.Sessions.Where(e => e.Assigned < e.Capacity).FirstOrDefault();
                if (evnt != null && session != null)
                {
                    session.Event.Staffs.Add(staff);
                    session.Assigned++;
                    Training training = new Training();
                    training.Event_ID = evnt.ID;
                    training.Session_ID = session.ID;
                    training.Staff_ID = staff.ID;
                    dataContext.Trainings.Add(training);
                    dataContext.SaveChanges();
                }
            }
        }

        public void LimitCapacity(Session sessionParam, int capacity)
        {
            Session originalSession = dataContext.Sessions.Find(sessionParam.ID);
            originalSession.Capacity = capacity;
            dataContext.SaveChanges();
        }

        public void InserStaff(Staff staff)
        {
            dataContext.Staffs.Add(staff);
            dataContext.SaveChanges();
        }

        public void EditStaff(Staff staff)
        {
            dataContext.Entry(staff).State = EntityState.Modified;
            dataContext.SaveChanges();
        }
        public void DeleteStaff(int id)
        {
            Staff staff = dataContext.Staffs.Find(id);
            dataContext.Staffs.Remove(staff);
            dataContext.SaveChanges();
        }
        
        public void InsertSession(Session session)
        {
            dataContext.Sessions.Add(session);
            dataContext.SaveChanges();
        }

        public void DeleteSession(int id)
        {
            Session session = dataContext.Sessions.Find(id);
            dataContext.Sessions.Remove(session);
            dataContext.SaveChanges();
        }

        
        /*Add Assigned Staff in Assigned Table*/
       public void AddAssignedStaff(AssignedStaff assigned)
        {
            dataContext.AssignedStaffs.Add(assigned);
            dataContext.SaveChanges();
        }

      
    }
}
